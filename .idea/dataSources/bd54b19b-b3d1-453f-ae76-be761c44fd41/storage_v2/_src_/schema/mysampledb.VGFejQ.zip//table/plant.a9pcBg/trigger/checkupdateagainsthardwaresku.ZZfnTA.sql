CREATE DEFINER = root@localhost TRIGGER checkUpdateAgainstHardwareSKU
    BEFORE UPDATE
    ON plant
    FOR EACH ROW
BEGIN
    IF (new.SKU IN (SELECT SKU FROM Hardware WHERE SKU = new.SKU)) THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'The SKU already exists in Hardware';
    END IF;
END;

